/*
    Boar Daniel-Ioan
    Grupa 30223

    In metoda Quicksort am evaluat algoritmul pentru cazurile mediu static, favorbail si defavorabil.
    Cazul mediu static este atunci cand vectorul e nesortat, cazul favorabil este cand in sir pivotul este luat la mijloc, sau poate fi chiar si nesortat, 
    iar in cazul worst vectorul este luat fie ordonat crescator, fie descrescator.
    Complexitate in worst_case este O(n^2), iar in celelalte este O(n * log n).

    Am impelementat si algoritmul heapsort ce are o complexitate O(n * log n) deoarece se foloseste si de heapify si de bottom_up.
    Am realizat graficele comparative pentru cele 2 metode (heapsort si quicksort), pe cazul mediu static, si putem observa ca algoritmul quicksort este mult mai eficient, 
    facand mai putine comparatii si atribuiri decat heapsort.

    Pentru cerinta comparativa a 2 metode de sortare din primul laborator, am ales sa implementez metoda bubble sort, iterativa si recursiva pe cazul mediu static.
    De pe grafice am putut observa ca metoda recursiva este mult mai eficienta din punct de vedere al nr de operatii.
    Din punct de vedere al timpului de executie, la un nr destul de mare de teste (100 / 5), se poate observa ca metoda iterativa este mai eficienta decat cea recursiva.
    Bubble are complexitate O(n^2).
 */

#include <iostream>
#include "Profiler.h"

Profiler P("QuickSort");

using namespace std;
#define MAX_SIZE 10000
#define STEP_SIZE 100
#define NR_TESTS 5
#define NR_TESTS2 100

int PARTITION(int a[], int p, int r, Operation& opComp, Operation& opAttr) {
    int x = a[r];
    int i;
    i = p - 1;
    for (int j = p; j <= r - 1; j++) {
        opComp.count();
        if(a[j] <= x) {
            i = i + 1;
            opAttr.count(3);
            swap(a[i], a[j]);
        }
    }
    opAttr.count(3);
    swap(a[i + 1], a[r]);
    return (i + 1);
}

void QUICKSORT(int a[], int p, int r, Operation& opComp, Operation& opAttr) {
    int q;
    opComp.count();
    if (p < r) {
        q = PARTITION(a, p, r, opComp, opAttr);
        QUICKSORT(a, p, q - 1, opComp, opAttr);
        QUICKSORT(a, q + 1, r, opComp, opAttr);
    }
}

void ApelareQuick(int a[], int p, int r) {
    Operation opComp = P.createOperation("q.comp", r + 1);
    Operation opAttr = P.createOperation("q.attr", r + 1);
    QUICKSORT(a, p, r, opComp, opAttr);
}

void MAX_HEAPIFY(int a[], int n, int i, Operation& opComp, Operation& opAttr) {
    int largest = i;
    int l = 2 * i + 1;
    int r = 2 * i + 2;
    opComp.count();
    if (l <n && a[l] > a[i])
        largest = l;
    else
        largest = i;
    opComp.count();
    if (r < n && a[r] > a[largest])
        largest = r;
    if (largest != i) {
        opAttr.count(3);
        swap(a[i], a[largest]);
        MAX_HEAPIFY(a, n, largest, opComp, opAttr);
    }
}

void BUILD_MAX_HEAP(int a[], int n, Operation& opComp, Operation& opAttr) {
    int heap_size = n;
    for (int i = (heap_size / 2) - 1; i >= 0; i--) {
        MAX_HEAPIFY(a, n, i, opComp, opAttr);
    }
}

void HEAPSORT(int a[], int n) {
    Operation opComp = P.createOperation("heapsort.comp", n);
    Operation opAttr = P.createOperation("heapsort.attr", n);
    int i, heap_size = n;
    BUILD_MAX_HEAP(a, heap_size, opComp, opAttr);
    for (i = n - 1; i >= 1; i--) {
        opAttr.count(3);
        swap(a[0], a[i]);
        heap_size--;
        MAX_HEAPIFY(a, heap_size, 0, opComp, opAttr);
    }
}

void bubblesort(int a[], int n) {
    Operation opComp = P.createOperation("b.comp", n);
    Operation opAttr = P.createOperation("b.attr", n);
    int aux;
    bool ok;
    do
    {
        ok = true;
        for (int i = 0; i < n - 1; i++) {
            opComp.count();
            if (a[i] > a[i + 1])
            {
                opAttr.count(3);
                int aux = a[i];
                a[i] = a[i + 1];
                a[i + 1] = aux;
                ok = false;
            }
        }
    } while (ok == false);
}

void bubblesort_recursiv(int a[], int n, Operation& opComp, Operation& opAttr) {
    if (n == 1)
        return;
    else {
        for (int i = 0; i < n - 1; i++) {
            opComp.count();
            if (a[i] > a[i + 1]){
                opAttr.count(3);
                swap(a[i], a[i + 1]);
            }
        }
        bubblesort_recursiv(a, n - 1, opComp, opAttr);
    }
}

void apelare_bubble_rec(int a[], int n) {
    Operation opComp = P.createOperation("b_r.comp", n);
    Operation opAttr = P.createOperation("b_r.attr", n);
    bubblesort_recursiv(a, n, opComp, opAttr);
}

void demo() {
    int a[] = { 10,8,5,4,3,2,1 };
    int n = sizeof(a) / sizeof(a[0]);
    int b[1000];
    int c[1000];
    int d[1000];
    for (int i = 0; i < n; i++)
    {       b[i] = a[i];
            c[i] = a[i];
            d[i] = a[i];
    }
    cout << "QUICKSORT: ";
    ApelareQuick(a, 0, n - 1);
    for (int i = 0; i < n; i++)
        cout << a[i] << " ";
    cout << endl;
    cout << "HEAPSORT: ";
    HEAPSORT(b, n);
    for (int i = 0; i < n; i++)
        cout << b[i] << " ";
    cout << endl;
    cout << "BUBBLESORT: ";
    bubblesort(c, n);
    for (int i = 0; i < n; i++)
        cout << c[i] << " ";
    cout << endl;
    cout << "BUBBLESORT RECURSIV: ";
    apelare_bubble_rec(d, n);
    for (int i = 0; i < n; i++)
        cout << d[i] << " ";
    cout << endl;
    
   
}

void perf(int order) {
    int a[MAX_SIZE];
    int n;
    int b[MAX_SIZE];
    for (n = STEP_SIZE; n <= MAX_SIZE; n += STEP_SIZE) {
        for (int test = 0; test < NR_TESTS; test++) {
            FillRandomArray(a, n, 100, 10000, false, order);
            for (int i = 0; i < n; i++) {
                b[i] = a[i];   // am creat copii ale vectorului initial pentru a nu ne trimite la celelalte subprograme sirul sortat
            }
            ApelareQuick(a, 0, n - 1);  
            HEAPSORT(b, n);
        }
    }

    P.divideValues("q.attr", NR_TESTS);
    P.divideValues("q.comp", NR_TESTS);
    P.addSeries("quicksort", "q.attr", "q.comp");
    
    P.divideValues("heapsort.attr", NR_TESTS);
    P.divideValues("heapsort.comp", NR_TESTS);
    P.addSeries("heapsort", "heapsort.attr", "heapsort.comp");

    P.createGroup("attr", "q.attr", "heapsort.attr");
    P.createGroup("comp", "q.comp", "heapsort.comp");
    P.createGroup("total", "quicksort", "heapsort");

    P.showReport();

}

void best_case() { //best case quicksort
    int a[MAX_SIZE];
    int n;
    for (n = STEP_SIZE; n <= MAX_SIZE; n += STEP_SIZE) {
        for (int test = 0; test < NR_TESTS; test++) {
            FillRandomArray(a, n, 100, 10000, false, 0);
            ApelareQuick(a, 0, (n - 1) / 2); //best case cu pivotul luat la jumatatea vectorului.
        }
    }
   
    P.divideValues("q.attr", NR_TESTS);
    P.divideValues("q.comp", NR_TESTS);
    P.addSeries("quicksort", "q.attr", "q.comp");
    P.showReport();

}

void perf_bubble(int order) {
    int a[MAX_SIZE];
    int n;
    int b[MAX_SIZE];
    int c[MAX_SIZE];
    int d[MAX_SIZE];

    for (n = STEP_SIZE; n <= MAX_SIZE; n += STEP_SIZE) {
        for (int test = 0; test < NR_TESTS; test++) {
            FillRandomArray(a, n, 100, 10000, false, order);
            CopyArray(b, a, n);
            CopyArray(c, a, n);
            CopyArray(d, a, n);
            bubblesort(a, n);
            apelare_bubble_rec(b, n);
        }

        P.startTimer("bubblesort", n);
        for (int test = 0; test < NR_TESTS2; test++) {
            bubblesort(c, n);
        }
        P.stopTimer("bubblesort", n);

        P.startTimer("apelare_bubble_rec", n);
        for (int test = 0; test < NR_TESTS2; test++) {
            apelare_bubble_rec(d, n);
        }
        P.stopTimer("apelare_bubble_rec", n);

    }

    P.divideValues("b.attr", NR_TESTS);
    P.divideValues("b.comp", NR_TESTS);
    P.addSeries("bubble", "b.attr", "b.comp");

    
    P.divideValues("b_r.attr", NR_TESTS);
    P.divideValues("b_r.comp", NR_TESTS);
    P.addSeries("bubble_recursiv", "b_r.attr", "b_r.comp");


    P.createGroup("attr", "b.attr", "b_r.attr");
    P.createGroup("comp", "b.comp", "b_r.comp");
    P.createGroup("total", "bubble", "bubble_recursiv");

    P.createGroup("total_time", "bubblesort", "apelare_bubble_rec");

    P.showReport();
}

void perf_all() {
    //P.reset("Mediu_staic");
    //perf(UNSORTED); //verificare normala, nesortat
    //P.reset("Best_case");
    //best_case(); //best case, pivotul la jumatatea vectorului
    //P.reset("Worst_case");
    //perf(ASCENDING); //worst case daca alegem pivotul cel mai din stanga, vector crescator
    perf_bubble(UNSORTED);
}

int main()
{
    demo();
    //perf_all();
    return 0;

}
