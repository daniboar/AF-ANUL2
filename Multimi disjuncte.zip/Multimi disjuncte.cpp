/*
    Boar Daniel Ioan   
    Grupa 30223

    In aceasta tema am avut de implementat operatiile pe multimi disjuncte si algoritmul lui Kruskal.
    Pentru multimi disjuncte a trebuit sa fac operatiile de baza : MAKE_SET, UNION si FIND_SET.

    Pentru algoritmul lui Kruscal am creat un graf cu ponderi si a trebuit sa returnez un graf cu ponderi minime, astfel incat sa nu existe cicluri.
    ->am ordonat fiecare muchie in ordine crescatoare dupa pondere
    ->am verificat fiecare muchie daca face parte dintr-un subarbore. Daca da, ignoram, altfel adaugam muchia cu ponderea respeciva
*/

#include <iostream>

using namespace std;

typedef struct Node {
    int rank;
    char nume;
    Node* parinte;
};

Node* MAKE_SET(char x) {
    Node* a = (Node*)malloc(sizeof(Node));
    a->nume = x;
    a->rank = 0;
    a->parinte = a;
    return a;  
}

void LINK(Node* x, Node* y) {
    if (x->rank > y->rank)
        y->parinte = x;
    else {
        x->parinte = y;
        if (x->rank == y->rank)
            y->rank = y->rank + 1;
         }
}

Node* FIND_SET(Node* a) {
    if (a != a->parinte)
        a->parinte = FIND_SET(a->parinte);
    return a->parinte;
}

void UNION(Node* x, Node* y) {
    LINK(FIND_SET(x), FIND_SET(y));
}

typedef struct Muchie {
    int  sursa;
    int destinatie;
    int w;
};

typedef struct Graf {
    int V, E;  //nr de varfuri si de muchii
    struct Muchie* muchie;
};

Graf* createGraf(int V, int  E) {
    Graf* g = (Graf*)malloc(sizeof(Graf));
    g->V = V;
    g->E = E;
    g->muchie = (Muchie*)malloc(sizeof(Muchie));
    return g;
}

typedef struct mult {
    int parinte;
    int rank;
};

int FIND_SET2(mult* a, int i) {
    if (a[i].parinte != i)
        a[i].parinte = FIND_SET2(a, a[i].parinte);
    return a[i].parinte;
}

void UNION2(mult* a, int x, int y) {
    int root1 = FIND_SET2(a, x);
    int root2 = FIND_SET2(a, y);
    if (a[root1].rank < a[root2].rank)
        a[root1].parinte = root2;
    else if (a[root1].rank > a[root2].rank)
        a[root2].parinte = root1;
    else {
        a[root2].parinte = root1;
        a[root1].rank = a[root1].rank + 1;
    }
}

Muchie* Kruskal(Graf* G) {
    Muchie* A = (Muchie*)malloc(G->E * sizeof(Muchie));
    mult* a = (mult*)malloc(G->V * sizeof(mult));
    for (int i = 0; i < G->V; i++) { //MAKE_SET
        a[i].parinte = i;
        a[i].rank = 0;
    }
   
    // sortare muchii dupa weight
    bool ok;
    do {
        ok = true;
        for (int i = 0; i < G->E - 1; i++) {
            if (G->muchie[i].w > G->muchie[i + 1].w) {
                swap(G->muchie[i].w, G->muchie[i + 1].w);
                swap(G->muchie[i].sursa, G->muchie[i + 1].sursa);
                swap(G->muchie[i].destinatie, G->muchie[i + 1].destinatie);
                ok = false;
            }
        }
    } while (ok == false);

    //afisez muchiile ordonate dupa pondere
    //cout << "Muchiile arborelui ordonate dupa pondere:\n";
    /*for (int i = 0; i < G->E; i++)
        cout << G->muchie[i].sursa << " <--> " << G->muchie[i].destinatie << " = " << G->muchie[i].w << "\n";*/
    //cout << "\n";
    int l = -1;
    for (int i = 0; i < G->E; i++) {
        Muchie next_muchie = G->muchie[i];
        int x = FIND_SET2(a, next_muchie.sursa);
        int y = FIND_SET2(a, next_muchie.destinatie);
        if (x != y) {
            l++;
            A[l] = next_muchie;
            UNION2(a, x, y);
        }
    }

    return A;
}

void demo1() {
    Node* a, * b, * c, * d;
    a = MAKE_SET('a');
    b = MAKE_SET('b');
    c = MAKE_SET('c');
    d = MAKE_SET('d');
    UNION(a, b);
    UNION(b, c);
    UNION(c, d);
    cout << "Rank a: " << a->rank << "\n";
    cout << "Rank b: " << b->rank << "\n";
    cout << "Rank c: " << c->rank << "\n";
    cout << "Rank d: " << d->rank << "\n";
    cout << "Parintele lui a este: " << a->parinte->nume << "\n";
    cout << "Parintele lui b este: " << b->parinte->nume << "\n";
    cout << "Parintele lui c este: " << c->parinte->nume << "\n";
    cout << "Parintele lui d este: " << d->parinte->nume << "\n";
}

void demo2() {
    int V, E;
    V = 9;
    E = 14;
    Graf* g = createGraf(V, E);
    g->muchie[0].sursa = 0;
    g->muchie[0].destinatie = 1;
    g->muchie[0].w = 4;

    g->muchie[1].sursa = 0;
    g->muchie[1].destinatie = 7;
    g->muchie[1].w = 8;

    g->muchie[2].sursa = 1;
    g->muchie[2].destinatie = 2;
    g->muchie[2].w = 8;

    g->muchie[3].sursa = 1;
    g->muchie[3].destinatie = 7;
    g->muchie[3].w = 11;

    g->muchie[4].sursa = 2;
    g->muchie[4].destinatie = 3;
    g->muchie[4].w = 7;

    g->muchie[5].sursa = 2;
    g->muchie[5].destinatie = 8;
    g->muchie[5].w = 2;

    g->muchie[6].sursa = 2;
    g->muchie[6].destinatie = 5;
    g->muchie[6].w = 4;

    g->muchie[7].sursa = 3;
    g->muchie[7].destinatie = 4;
    g->muchie[7].w = 9;

    g->muchie[8].sursa = 3;
    g->muchie[8].destinatie = 5;
    g->muchie[8].w = 14;

    g->muchie[9].sursa = 4;
    g->muchie[9].destinatie = 5;
    g->muchie[9].w = 10;

    g->muchie[10].sursa = 5;
    g->muchie[10].destinatie = 6;
    g->muchie[10].w = 2;

    g->muchie[11].sursa = 6;
    g->muchie[11].destinatie = 7;
    g->muchie[11].w = 1;

    g->muchie[12].sursa = 6;
    g->muchie[12].destinatie = 8;
    g->muchie[12].w = 6;

    g->muchie[13].sursa = 7;
    g->muchie[13].destinatie = 8;
    g->muchie[13].w = 7;

    Muchie* A = Kruskal(g);
    int suma_w = 0;
    cout << "Arborele de pondere minima: \n";
    for (int i = 0; i < 8; i++) {
        cout << A[i].sursa << " <--> " << A[i].destinatie << " = " << A[i].w << "\n";
        suma_w += A[i].w;
    }
    cout << "\n";
    cout << "Suma minima a ponderilor este: " << suma_w << "\n";
}

int main()
{
    demo1();
    cout << "\n";
    demo2();
    return 0;
}