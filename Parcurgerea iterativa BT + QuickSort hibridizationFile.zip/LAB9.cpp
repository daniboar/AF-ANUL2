/*
	Boar Daniel Ioan	
	Grupa 30223

	Am implementat algoritmul pentru hibridizare quicksort care la un prag mai mic de 20, se foloseste de insertion sort.
	Am comparat acest algoritm cu cel de quicksort normal din punctu de vedere al nr de operatii facute si al timpului. Pe baza graficelor am putut observa ca cele 2 sunt aproape similare,
	algoritmul de hibridizare avand un nr putin mai mare de operatii.

	Al 2 lea lucru implementat a fost parcurgerea in preordine iterativa si recrusiva a unui arbore binar.
	Partea iterativa nu mi-a iesit deoarece nu stiam cum sa dau free doar la un anumit element, eu probabil dadeam free la toata stiva si imi afisa acelasi lucru.
	De pe grafic se poate observa ca cele 2 metode au acelasi nr de afisari, cum era si normal.

*/

#include <iostream>
#include "Profiler.h"
using namespace std;

Profiler P("QuickSortHIB");

#define MAX_SIZE 1000
#define STEP_SIZE 100
#define NR_TESTS 5
#define NR_TESTS2 100

typedef struct node
{
	int key;
	struct node* next;
} NodeT;

typedef struct Node {
	int key;
	struct Node* left;
	struct Node* right;
};

NodeT* createS(Node* x)
{
	NodeT* q = (NodeT*)malloc(sizeof(NodeT));
	q->key = x->key;
	q->next = NULL;
	return q;
}

Node* create(int key) {
	Node* p = (Node*)malloc(sizeof(Node));
	p->key = key;
	p->left = NULL;
	p->right = NULL;
	return p;
}

Node* BUILD_TREE(int* a, int l, int r) {
	if (l > r)
		return NULL;
	int middle = (l + r) / 2;  //alegem elementrul din mijlocul vectorului pentru a face un BST 
	Node* root = create(a[middle]);
	root->left = BUILD_TREE(a, l, middle - 1); //creez arborele stang
	root->right = BUILD_TREE(a, middle + 1, r); //creez arborele drept
	return root;
}

void preorder(Node* root, int n, Operation& opComp) { // RSD
	if (root != NULL) {
		opComp.count();
		cout << root->key << " ";
		preorder(root->left, n, opComp);
		preorder(root->right, n, opComp);
	}
}

void apelare_preorder(Node* root, int n) {
	Operation opComp = P.createOperation("rec.comp", n);
	preorder(root, n, opComp);
}

void push(NodeT** stack, Node* x)
{
	NodeT* q = createS(x);
	if (*stack == NULL)
		*stack = q;
	else
	{
		q->next = *stack;
		*stack = q;
	}
}

Node* pop(NodeT** stack)
{
	Node* x;
	if (*stack == NULL)
	{
		puts("stiva e goala");
		return NULL;
	}
	else
	{
		NodeT* q = (*stack)->next;
		x = create(q->key);
		free(*stack);
		*stack = q;
	}
	return x;
}

void preorder_it(Node* root, int n) {
	Operation opComp = P.createOperation("itt.comp", n);
	if (root == NULL)
		return;
	int aux = 0;
	NodeT* s;  // am creat un stack unde vom pune cate un element din arbore
	push(&s, root);
	while (aux < n) {
		Node* a;
		opComp.count();
		cout << s->key << " ";
		pop(&s); //stergem elementul de pe stiva
		aux++;
		if (root->right != NULL) //punem pe stiva copilul drept
			push(&s, root->right);
		if (root->left != NULL) // punem pe stiva copilul stanga
			push(&s, root->left);
	}
}

int partition(int a[], int p, int r, Operation& opComp, Operation& opAttr) {
	opAttr.count();
	int x = a[r];
	int i;
	i = p - 1;
	for (int j = p; j <= r - 1; j++) {
		opComp.count();
		if (a[j] <= x) {
			i = i + 1;
			opAttr.count(3);
			swap(a[i], a[j]);
		}
	}
	opAttr.count(3);
	swap(a[i + 1], a[r]);
	return (i + 1);
}

void insertion(int* a, int p, int n, Operation& opComp, Operation& opAttr) {
	int key, j;
	for (int i = p; i < n; i++) {
		opAttr.count();
		key = a[i];
		j = i - 1;;
		while (j >= 0 && a[j] > key) {
			opComp.count();
			opAttr.count();
			a[j + 1] = a[j];
			j--;
		}
		opAttr.count();
		a[j + 1] = key;
	}
}

void QS(int* a, int p, int r, Operation& opComp, Operation& opAttr) {
	if (p < r) {
		if (r - p < 20)
			insertion(a, p, r, opComp, opAttr);
		else {
			int q = partition(a, p, r, opComp, opAttr);
			QS(a, p, q - 1, opComp, opAttr);
			QS(a, q + 1, r, opComp, opAttr);
		}
	}
}

void ApelareQuickH(int a[], int p, int r) {
	Operation opComp = P.createOperation("qh.comp", r);
	Operation opAttr = P.createOperation("qh.attr", r);
	QS(a, p, r, opComp, opAttr);
}

void QUICKSORT(int a[], int p, int r, Operation& opComp, Operation& opAttr) {
	int q;
	if (p < r) {
		q = partition(a, p, r, opComp, opAttr);
		QUICKSORT(a, p, q - 1, opComp, opAttr);
		QUICKSORT(a, q + 1, r, opComp, opAttr);
	}
}

void ApelareQuick(int a[], int p, int r) {
	Operation opComp = P.createOperation("q.comp", r + 1);
	Operation opAttr = P.createOperation("q.attr", r + 1);
	QUICKSORT(a, p, r, opComp, opAttr);
}

void demo1() {
	int a[] = { 1,2,3,4,5,6,7,8,9,10,11 };
	int n = sizeof(a) / sizeof(a[0]);
	Node* root = BUILD_TREE(a, 0, n - 1);
	cout << "Preordine recursiv: ";
	apelare_preorder(root, n);
	cout << "\n";
	cout << "Preordine iterativ: ";
	preorder_it(root, n );
}

void demo2() {
	int a[] = { 3,4,1,5,10,6,2 };
	int n = sizeof(a) / sizeof(a[0]);
	int b[100];
	CopyArray(b, a, n);
	ApelareQuickH(a, 0, n);
	ApelareQuick(b, 0, n - 1);
	cout << "Hibridizare quicksort: ";
	for (int i = 0; i < n; i++)
		cout << a[i] << " ";
	cout << "\n";
	cout << "Quicksort: ";
	for (int i = 0; i < n; i++)
		cout << b[i] << " ";
}

void perf1(int order) {
	int a[MAX_SIZE];
	int n;
	int b[MAX_SIZE];
	int c[MAX_SIZE];
	int d[MAX_SIZE];
	for (n = STEP_SIZE; n <= MAX_SIZE; n += STEP_SIZE) {
		for (int test = 0; test < NR_TESTS; test++) {
			FillRandomArray(a, n, 100, 10000, false, order);
			for (int i = 0; i < n; i++) {
				b[i] = a[i];   // am creat copii ale vectorului initial pentru a nu ne trimite la celelalte subprograme sirul sortat
				CopyArray(c, a, n);
				CopyArray(d, a, n);
			}
			ApelareQuick(a, 0, n - 1);
			ApelareQuickH(b, 0, n);
		}
	
		P.startTimer("quicksort_time", n);
		for (int test = 0; test < NR_TESTS2; test++) {
			ApelareQuick(c, 0, n - 1);
		}
		P.stopTimer("quicksort_time", n );

		P.startTimer("quick_hib_time", n);
		for (int test = 0; test < NR_TESTS2; test++) {
			ApelareQuickH(d, 0, n);
		}
		P.stopTimer("quick_hib_time", n);
	}

	P.divideValues("q.attr", NR_TESTS);
	P.divideValues("q.comp", NR_TESTS);
	P.addSeries("quicksort", "q.attr", "q.comp");

	P.divideValues("qh.attr", NR_TESTS);
	P.divideValues("qh.comp", NR_TESTS);
	P.addSeries("quick_hib", "qh.attr", "qh.comp");

	P.createGroup("attr", "q.attr", "qh.attr");
	P.createGroup("comp", "q.comp", "qh.comp");
	P.createGroup("total", "quicksort", "quick_hib");

	P.createGroup("time", "quicksort_time", "quick_hib_time");

	P.showReport();
}

void perf2(int order) {
	int a[MAX_SIZE];
	int n;
	int b[MAX_SIZE];
	for (n = STEP_SIZE; n <= MAX_SIZE; n += STEP_SIZE) {
		for (int test = 0; test < NR_TESTS; test++) {
			FillRandomArray(a, n, 100, 10000, false, order);
			Node* root = BUILD_TREE(a, 0, n - 1);
			apelare_preorder(root, n);
			preorder_it(root, n);
		}
	}

	P.divideValues("rec.comp", NR_TESTS);
	P.divideValues("itt.comp", NR_TESTS);
	P.createGroup("afisari", "rec.comp", "itt.comp");

	P.showReport();
}

int main()
{
	demo1();
	cout << "\n";
	demo2();
	//perf1(UNSORTED);
	//perf2(ASCENDING);
	return 0;
}