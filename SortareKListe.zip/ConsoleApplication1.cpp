/*
    Boar Daniel-Ioan
    Grupa 30223

    In aceasta tema am avut de implementat un algoritm ce ne genereaza k liste random si le sorteaza.
    Prima data am implementat algoritmul de sortare a 2 clase, apoi m-am folosit de acest algoritm pentru a sorta cele k liste generate random.
    Pe langa algoritmul de sortare, am avut nevoie si de un algoritm de merge_sort, in care m-am folosit de sortarea a 2 liste, in merge facand interclasarea listelor 2  cate 2.
    Pentru listele random am introdus cate un element in fiecare lista pentru a nu avea nicio lista goala apoi am introds pe coloane random din matricea de liste
    cate un element aleator. Nr total de elemente din liste este n.
    Am incercat sa implementez si algoritmul de Min_Heap folosind listele, dar am reusit sa fac structura si heapify-ul pt min si build_min_heap, nefolosindu-ma de aceste
    subprograme in program.
    Complexitatea algoritmului de sortarea a k liste este de O(n * log k).
 */


#include <iostream>
#include "Profiler.h"

Profiler p("MergeKListe");
using namespace std;

typedef struct node
{
    int x;
    struct node* next;
} NodeT;

typedef struct heap {
    int key, index;
    struct heap* next;
}Heap;

NodeT* create(int x)
{
    NodeT* q = (NodeT*)malloc(sizeof(NodeT));
    q->x = x ;
    q->next = NULL;
    return q;
}
void insert(NodeT** first, NodeT** last, int x)
{
    NodeT* q = create(x);
    if (*first == NULL)
    {
        *first = q;
        *last = q;
    }
    else
    {
        (*last)->next = q;
        *last = q;
    }
}

void MIN_HEAPIFY(Heap* a, int n, int i) {
    int smallest = i;
    int l = 2 * i + 1;
    int r = 2 * i + 2;
    if (l < n && a[l].key < a[i].key)
        smallest = l;
    else
        smallest = i;
    if (r < n && a[r].key < a[smallest].key)
        smallest = r;
    if (smallest != i) {
        swap(a[i].key, a[smallest].key);
        swap(a[i].index, a[smallest].index);
        MIN_HEAPIFY(a, n, smallest);
    }
}

void BUILD_MIN_HEAP(Heap* a, int n) {
    int heap_size = n;
    for (int i = (heap_size - 1) / 2; i >= 0; i--) {
        MIN_HEAPIFY(a, n, i);
    }
}

void afisareLista(NodeT* first)
{
    for (NodeT* a = first; a != NULL; a = a->next)
        cout<< a->x << " ";
    cout << endl;
}

NodeT* sortare(NodeT* k1, NodeT* k2) {
    NodeT* q = NULL;
    if (k1 == NULL) //daca prima lista e nula, returnam a 2 a lista care este deja sortata
        return k2;
    else if (k2 == NULL) //daca a doua lista e nula ,returnam prima lista sortata
            return k1;
    if (k1->x <= k2->x) {
        q = k1;
        q->next = sortare(k1->next, k2);
    }
    else {
        q = k2;
        q->next = sortare(k1, k2->next);
    }
    return q;
}

NodeT* merge_sort(NodeT** a, int last) {
    while (last != 0) { //cat timp avem o lista
        int i = 0;
        int j = last;
        while (i < j) {
            a[i] = sortare(a[i], a[j]); //facem merge_sort in lista i
            i++;
            j--;   //urmatoarea pereche (i,j)
            if (i >= j) //daca am facut merge pe toate perechile schimbam last-ul
                last = j;
        }
    }
    return a[0];
    //pentru 4 liste, algoritmul va face sortare intre (a[0],a[3]), (a[1],a[2]) si la sfarsit (a[0],a[1]) --> returneza a[0] ce reprezinta o lista cu toate elementele sortate
}

void demo_interclasare() {
    NodeT* first;
    NodeT* last;
    NodeT* first2;
    NodeT* last2;
    first2 = last2 = NULL;
    first = last = NULL;
    insert(&first, &last, 1);
    insert(&first, &last, 2);
    insert(&first, &last, 3);
    insert(&first, &last, 6);
    insert(&first, &last, 8);
    insert(&first, &last, 12);

    insert(&first2, &last2, 4);
    insert(&first2, &last2, 5);
    insert(&first2, &last2, 7);
    insert(&first2, &last2, 9);
    cout << "Lista1: ";
    afisareLista(first); // 1,2,3,6,8,12
    cout << "Lista2: ";
    afisareLista(first2); //4,5,7,9
    cout << "Interclasare: ";
    afisareLista(sortare(first, first2));
}

void demo_kliste(int k, int n) {
    NodeT* first[10000];
    NodeT* last[10000];
    int b[10000] = {}; //sirul de elemente care vor fi inserate in liste
    static int a[10000][10000] = {}; //matricea de liste
    int l[10000] = {}; //vector de coloane din matrice
    int i, j, x, nr, aux;
    srand(time(NULL));  
    FillRandomArray(b, n, 0, 1000, false, 1); 
    for (i = 0; i < k; i++)
        a[i][0] = b[i]; //am introdus cate un element in fiecare lista pt a nu avea liste goale
    for (i = k; i < n; i++) { 
         nr =  rand() % k; //alegem o lista random din cele k 
         aux = ++l[nr];   //incrementam coloana din lista random aleasa
        a[nr][aux] = b[i];     
    }
    for (i = 0; i < k; i++) {
            first[i] = last[i] = NULL;
            for (j = 0; j < n; j++) {
                if (a[i][j] != 0) {
                x = a[i][j];
                insert(&first[i], &last[i], x);//inseram elementul x in lista i
                }  
            }
            cout << "Lista" << i + 1 << " este: "; // afisam pe rand lista i pentru a putea vedea ce liste sortam
            afisareLista(first[i]);
    }
        NodeT* root = merge_sort(first, k - 1); // facem merge sort intre toate cele k liste
        cout << "Listele sortate: ";
        afisareLista(root);
        cout << "\n";
   
}
int main()
{
    demo_interclasare();
    cout << "\n";
    demo_kliste(4,20); //k = 4, n = 20
}

