/*
    Boar Daniel-Ioan
    Grupa 30223

    Am implementat 2 metode de a creea un heap folosind un array a.

    Prima metoda folosita este bottom_up. Aceasta metoda este alcatuita din 2 subprograme: MAX_HEAPIFY SI BUILD_MAX_HEAP.
        -->Fiecare apelare a MAX_HEAPIFY are complexitate O(log n) si BUILD_MAX_HEAP are cate o complexitate de O(n) la fiecare apelare. Algoritmul are complexitate in timp de O(n*log n).
        -->Se verifica toti stramosii 

    A doua metoda este top_down. In acest algorimt ne folosim de 3 subprograme: BUILD_MAX_HEAP2, MAX_HEAP_INSERT, HEAP_INCREASE_KEY.
        -->HEAP_INCREASE_KEY are complexitate O(log n), MAX_HEAP_INSERT O(log n) ----> TOP_DOWN are complexitate O(n * log n)
        -->Elementul inserat se verifica cu cate un parinte
    
    In graficele atasate am verifact cazurile in care vectorii sunt fie crescatori, fie nesortati
    
    In cazul mediu static, se poate observa ca in metoda top_down se fac mult mai multe atribuirii, iar daca vorbim despre nr de comparatii, 
    cele 2 metode sunt aproape identice, bottom_up face cu putin mai multe operatii. Pe acest caz, mai eficient este bottom_up.

    In cazul worst, top_down executa mai multe operatii decat bottom_up.

    Pe baza analizei, bottom_up este mai eficient decat top_down pe amandoua cazurile.
*/

#include <iostream>
#include "Profiler.h"

Profiler p("Heap");

using namespace std;
#define MAX_SIZE 10000
#define STEP_SIZE 100
#define NR_TESTS 5

void MAX_HEAPIFY(int a[], int n, int i, Operation &opComp, Operation &opAttr) {
    int largest = i;
    int l = 2 * i + 1;
    int r = 2 * i + 2;
    opComp.count();
    if (l <n && a[l] > a[i])
        largest = l;
    else
        largest = i;
    opComp.count();
    if (r < n && a[r] > a[largest])
        largest = r;
    if (largest != i) {
        opAttr.count(3);
        swap(a[i], a[largest]);
        MAX_HEAPIFY(a, n, largest, opComp, opAttr);
    }
}

void BUILD_MAX_HEAP(int a[], int n) {
    int heap_size = n;
    for (int i = (heap_size / 2) - 1; i >= 0; i--) {
        Operation opComp = p.createOperation("bottomup.comp", n);
        Operation opAttr = p.createOperation("bottomup.attr", n);
        MAX_HEAPIFY(a, n, i,opComp, opAttr);
    }
}

//Complexitate O(n * log n)
void HEAPSORT(int a[], int n) {
    Operation opComp = p.createOperation("heapsort.comp", n);
    Operation opAttr = p.createOperation("heapsort.attr", n);
    int i, heap_size = n;
    BUILD_MAX_HEAP(a, heap_size);
    for (i = n - 1; i >= 1; i--) {
        opAttr.count(3);
        swap(a[0], a[i]);
        heap_size--;
        MAX_HEAPIFY(a, heap_size, 0, opComp, opAttr);
    }
}

int HEAP_MAXIMUM(int a[], int n) {
    return a[0];
}

//O(log n)
int HEAP_EXTRACT_MAX(int a[], int &n) {
    Operation opComp = p.createOperation("extract.comp", n);
    Operation opAttr = p.createOperation("extract.attr", n);
    if (n < 1)
        cout<< "heap underflow";
    opAttr.count(2);
    int max = a[0];
    a[0] = a[n - 1];
    n--;
    MAX_HEAPIFY(a, n, 0, opComp, opAttr);
    return max;
}

void HEAP_INCREASE_KEY(int a[], int i, int key, Operation &opComp, Operation &opAttr) {
    opComp.count();
    if (key < a[i])
        cout << "key este mai mic decat cheia curenta";
    opAttr.count();
    a[i] = key;
    int parent = (i - 1) / 2;  
    while (i > 0 && a[parent] < a[i]) {
        opComp.count();
        opAttr.count(3);
        swap(a[i], a[parent]);
        i = parent;
        parent = (i - 1) / 2;
    }
}

void MAX_HEAP_INSERT(int a[], int& m, int key, Operation &opComp, Operation &opAttr ) {
    m++; //heap_size
    a[m] = -10000;
    HEAP_INCREASE_KEY(a, m, key, opComp, opAttr);
}

void BUILD_MAX_HEAP2(int a[], int n) {
    int m = -1;
    for (int i = 0; i < n; i++) {
        Operation opComp = p.createOperation("topdown.comp", n);
        Operation opAttr = p.createOperation("topdown.attr", n);
        MAX_HEAP_INSERT(a, m, a[i], opComp, opAttr);
    }
}

void demo() {
    int a[] = {7, 12, 11, 7, 20, 13, 14, 31, 45};
    int n = sizeof(a) / sizeof(a[0]);
    int b[1000];
    for (int i = 0; i < n; i++)
        b[i] = a[i];
    cout << "BOTTOM_UP: ";
    BUILD_MAX_HEAP(a, n);
    for (int i = 0; i < n; i++)
        cout << a[i] << " ";
    cout << endl;
    cout << "HEAPSORT: ";
     HEAPSORT(a, n);
    for (int i = 0; i < n; i++)
        cout << a[i] << " ";
    cout << endl;
    cout << "TOP_DOWN: ";
    BUILD_MAX_HEAP2(b, n);
    for (int i = 0; i < n; i++)
        cout << b[i] << " ";
    cout << endl;
    cout << "Maximul din heap: " << HEAP_EXTRACT_MAX(b, n) << endl;
    cout << "Heap-ul dupa extragerea maximului: ";
    for (int i = 0; i < n; i++)
        cout << b[i] << " ";
    cout << endl;
}

void perf(int order) {
    int a[MAX_SIZE];
    int n;
    int b[MAX_SIZE];
    for (n = STEP_SIZE; n <= MAX_SIZE; n += STEP_SIZE) {
        for (int test = 0; test < NR_TESTS; test++) {
            FillRandomArray(a, n, 10, 50000, false, order);
            for (int i = 0; i < n; i++)
                b[i] = a[i];
            BUILD_MAX_HEAP(a, n);
            BUILD_MAX_HEAP2(b, n);
        }
    }

    p.divideValues("bottomup.attr", NR_TESTS);  
    p.divideValues("bottomup.comp", NR_TESTS);
    p.addSeries("bottomup", "bottomup.attr", "bottomup.comp");

    p.divideValues("topdown.attr", NR_TESTS);
    p.divideValues("topdown.comp", NR_TESTS);
    p.addSeries("topdown", "topdown.attr", "topdown.comp");

    p.createGroup("attr", "bottomup.attr", "topdown.attr");
    p.createGroup("comp", "bottomup.comp", "topdown.comp");
    p.createGroup("total", "bottomup", "topdown");
    p.showReport();
}

void perf_all() {
    p.reset("mediu_static");
    perf(UNSORTED); //verificare normala (mediu static)
    p.reset("worst");
    perf(ASCENDING); // verificare pt worst case (sortat crescator)
}

int main()
{
    //demo();
    perf_all();
    return 0;
}


