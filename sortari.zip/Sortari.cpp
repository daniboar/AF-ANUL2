/*
    Boar Daniel-Ioan
    Grupa 30223
    
    Am implementat 3 variante pentru sortarea unui vector. Aceste variante sunt bubble, selection si insertion sort.
    
    a) Prima varianta, cea de bubble sort, ia fiecare pereche de elemente consecutive din vector si le ordoneaza daca acestea nu sunt in ordine. 
    Procesul se repeta pana cand sirul nu este sortat complet.
        ->Este un algorimt ineficient pe cel mai rau caz (descrescator) si are o complexitate de O(n^2).
        ->In schimb, in cel mai bun caz (crescator), aceasta metoda este cea mai eficienta din punct de vedere al nr  de operatii.
        ->Urmarind graficele, pot spune ca aceasta metoda este cea mai ineficient si in cazul unui sir nesortat.
   
    b) Selection sort ne cauta un minim intre pozitia la care suntem in vector, i, si n. Daca il gaseste printre cele i..n elemente, facem schimb intre a[i] si min.
        ->Este un algoritm eficient, avand o complexitate de O(n^2) datorita celor 2 for-uri.
        ->Uitandu-ne la grafice, aceasta metoda este cea mai eficienta cand vectorul este sortat descrescator si cand este nesortat.
        ->Aceasta varianta este ineficienta in cazul in care sirul este ordonat crescator.

    c) Ultima varianta, insertion sort, presupunem ca avem o parte sortata si una nesortata. 
    Luam un element a[i] si parcurgem elementele din stanga lui i, cautand un element mai mic sau egal cu acesta. 
    Daca exista un astfel de element, a[i] va fi inserat pe pozitia j+1 (pozitia de dupa elementul mai mic). La fiecare pas, trebuie mutate elementele cu o pozitie.
        ->Algoritmul are o complexitate de O(n^2).
        ->In cazul in care vectorul este nesortat, aceasta metoda este la fel de eficienta ca selection sort.
        ->Daca sirul este ordonat crescator, acest algoritm ruleaza in O(n) deoarece nu mai intra in a 2-a bucla for.
        ->In cazul worst (descrescator), complexitatea e de O(n^2).

    In urma analizei a celor 3 metode de sortate, am putut observa ca cea mai ineficienta varianta este metoda bubble sort, iar celelalte 2 sunt asemanatoare si aproape la fel de eficiente.
    
*/

#include <iostream>
#include "Profiler.h"

Profiler p("Sortari");

using namespace std;
#define MAX_SIZE 10000
#define STEP_SIZE 100
#define NR_TESTS 5

void bubblesort(int a[], int n) {
    Operation opComp = p.createOperation("b.comp", n);
    Operation opAttr = p.createOperation("b.attr", n);

    int aux;
    bool ok;
    do
    {
        ok = true;
        for (int i = 0; i < n - 1; i++) {
            opComp.count();
            if (a[i] > a[i + 1])
            {
                opAttr.count(3);
                int aux = a[i];
                a[i] = a[i + 1];
                a[i + 1] = aux;
                ok = false;
            }
        }
    } while (ok == false);
}

void selectionsort(int a[], int n) {
    
    Operation opComp = p.createOperation("s.comp", n);
    Operation opAttr = p.createOperation("s.attr", n);

    int ind;
    for (int i = 0; i < n-1; i++) {
        ind = i;
        for (int j = i + 1; j < n; j++) {
            opComp.count();
            if (a[j] < a[ind])
                ind = j;
        }
        if (ind != i)
        {
            opAttr.count(3);
            swap(a[ind], a[i]);
        }
    }
}

void insertionsort(int a[], int n) {

    Operation opComp = p.createOperation("i.comp", n);
    Operation opAttr = p.createOperation("i.attr", n);

    int key, j;
    for (int i = 1; i < n; i++) {
        opAttr.count();
        key = a[i];
        j = i - 1;
        while (j >= 0 && a[j] > key) {
            opComp.count();
            opAttr.count();
            a[j + 1] = a[j];
            j--;
        }
        opAttr.count();
        a[j + 1] = key;
    }
}

void demo() {
    int a[] = { 7, 2, 8, 5, 9, 1, 6 };
    int n = sizeof(a) / sizeof(a[0]);
    int b[100], c[100];
    for (int i = 0; i < n; i++) {
        b[i] = a[i];   // am creat copii ale vectorului initial pentru a nu ne trimite la celelalte subprograme sirul sortat
        c[i] = a[i];
    bubblesort(a, n);
    cout << "Bubble_Sort: ";
    for (int i = 0; i < n; i++)
        cout << a[i] << " ";
    cout << "\n";
    selectionsort(b, n);
    cout << "Selection_Sort: ";
    for (int i = 0; i < n; i++)
        cout << a[i] << " ";
    cout << "\n";
    insertionsort(c, n);
    cout << "Insertion_Sort: ";
    for (int i = 0; i < n; i++)
        cout << a[i] << " ";
    cout << "\n";
}

void perf(int order) {
    int a[MAX_SIZE];
    int n;
    int b[MAX_SIZE], c[MAX_SIZE];
    for (n = STEP_SIZE; n <= MAX_SIZE; n += STEP_SIZE) {
        for (int test = 0; test < NR_TESTS; test++) {
            FillRandomArray(a, n, 10, 50000, false, order);
            for (int i = 0; i < n; i++) {
                b[i] = a[i];   // am creat copii ale vectorului initial pentru a nu ne trimite la celelalte subprograme sirul sortat
                c[i] = a[i];
            }
            bubblesort(a, n);
            selectionsort(b, n);
            insertionsort(c, n);
        }
    }

    p.divideValues("b.attr", NR_TESTS);
    p.divideValues("b.comp", NR_TESTS);
    p.addSeries("bubble", "b.attr", "b.comp");  //Am creat graficul ce cuprinde nr de atribuiri si nr de comparatii pt metoda bubble

    p.divideValues("s.attr", NR_TESTS);
    p.divideValues("s.comp", NR_TESTS);
    p.addSeries("selection", "s.attr", "s.comp"); //Am creat graficul ce cuprinde nr de atribuiri si nr de comparatii pt metoda selection

    p.divideValues("i.attr", NR_TESTS);
    p.divideValues("i.comp", NR_TESTS);
    p.addSeries("insertion", "i.attr", "i.comp");//Am creat graficul ce cuprinde nr de atribuiri si nr de comparatii pt metoda insertion

    p.createGroup("attr", "b.attr", "s.attr", "i.attr"); //graficul cu totalul atribuirilor celor 3 metode
    p.createGroup("comp", "b.comp", "s.comp", "i.comp"); // graficul cu totalul comparatiilor celor 3 metode
    p.createGroup("total", "bubble", "selection", "insertion"); //attr + comp la toate 3 metodele
 
}

void perf_all() {
    perf(UNSORTED); //verificare normala (nesortat)
    p.reset("best");
    perf(ASCENDING); // verificare pt best case (sortat crescator)
    p.reset("worst");
    perf(DESCENDING); //verificare pt worst case (sortat descrescator)
    p.showReport();
}
int main()
{
    demo();
    //perf_all();
    return 0;
}

